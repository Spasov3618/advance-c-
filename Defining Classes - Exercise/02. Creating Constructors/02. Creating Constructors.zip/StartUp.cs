﻿using System;
using DefiningClasses;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {

        }
    }
}

